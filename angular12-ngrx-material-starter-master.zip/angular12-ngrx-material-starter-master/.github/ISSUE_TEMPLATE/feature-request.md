---
name: 💡 Feature request
about: I have a great idea!
---

<!--

* Please fill out this template with all the relevant information so we can
  understand what's going on and fix the issue. We appreciate bugs filed and PRs
  submitted!

* Please make sure that you are familiar with and follow the Code of Conduct for
  this project (found in the CODE_OF_CONDUCT.md file).

-->

## Describe the feature you'd like:

## Other information:

## I would be willing to submit a PR to fix this issue:

[ ] Yes (Assistance is provided if you need help submitting a pull request)  
[ ] No

<!--

If you are willing to submit a PR but are a bit unsure, feel free to check out the [Contributors Guide](CONTRIBUTING.md) for useful tips and hints that help you get started.

-->